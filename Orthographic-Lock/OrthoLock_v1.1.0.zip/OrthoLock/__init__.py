﻿# SPDX-License-Identifier: GPL-3.0-or-later
#
# OrthoLock
# Copyright (C) 2026 Pazelock
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

bl_info = {
    "name": "OrthoLock",
    "author": "Pazelock",
    "version": (1, 1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > N-Panel > View > OrthoLock",
    "description": (
        "Locks the viewport in Orthographic mode and enables free panning"
    ),
    "category": "3D View",
}

import bpy
from bpy.props import BoolProperty
from mathutils import Vector


# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

# True when OrthoLock auto-suspended itself because the user entered camera view.
# Cleared when the user manually disables the checkbox.
_suspended_for_camera = False

_watcher_handle = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _find_view3d_at_mouse(context, mouse_x, mouse_y):
    """
    Return (area, region, rv3d) for the VIEW_3D area under (mouse_x, mouse_y).
    Returns (None, None, None) if the mouse is not over any 3D viewport.
    """
    for area in context.screen.areas:
        if area.type != "VIEW_3D":
            continue
        if not (area.x <= mouse_x < area.x + area.width and
                area.y <= mouse_y < area.y + area.height):
            continue
        for region in area.regions:
            if region.type == "WINDOW":
                return area, region, area.spaces.active.region_3d
    return None, None, None


def _find_any_view3d(context):
    """Return (area, region, rv3d) for the first VIEW_3D found, or Nones."""
    for area in context.screen.areas:
        if area.type != "VIEW_3D":
            continue
        for region in area.regions:
            if region.type == "WINDOW":
                return area, region, area.spaces.active.region_3d
    return None, None, None


# ---------------------------------------------------------------------------
# Camera-exit watcher
# ---------------------------------------------------------------------------

def _camera_exit_watcher():
    """
    Runs every 3D viewport redraw.
    If OrthoLock was suspended for camera view and the viewport is no longer
    in camera mode, schedule a re-enable via a timer (not inline, to avoid
    conflicting with Blender's own camera-exit processing).
    """
    if not _suspended_for_camera:
        return

    context = bpy.context
    if context is None:
        return

    _, _, rv3d = _find_any_view3d(context)
    if rv3d is None:
        return

    if rv3d.view_perspective != "CAMERA":
        # Use a one-shot timer so Blender fully finishes its camera-exit
        # event handling before we start the modal again. Without the delay
        # the viewport can end up in a mid-transition state that causes an
        # unwanted rotation snap.
        bpy.app.timers.register(_reenable_lock, first_interval=0.05)
        # Unregister watcher immediately so it won't fire again before the
        # timer runs.
        _unregister_watcher()


def _reenable_lock():
    """Timer callback: re-enable OrthoLock after camera exit."""
    global _suspended_for_camera
    _suspended_for_camera = False
    wm = bpy.context.window_manager if bpy.context else None
    if wm is not None:
        wm.ortholock_active = True
    return None  # don't repeat


# ---------------------------------------------------------------------------
# Modal operator
# ---------------------------------------------------------------------------

class VIEW3D_OT_ortholock_modal(bpy.types.Operator):
    """Active while OrthoLock is engaged - intercepts input to enforce the lock."""
    bl_idname  = "view3d.ortholock_modal"
    bl_label   = "OrthoLock Modal"
    bl_options = {"INTERNAL"}

    _timers: dict = {}

    def modal(self, context, event):
        global _suspended_for_camera

        wm = context.window_manager

        if not wm.ortholock_active:
            self._cleanup(context)
            return {"CANCELLED"}

        # Only act on events when the mouse is inside a 3D viewport.
        # For TIMER events mouse coords are 0,0 - use find_any instead.
        if event.type == "TIMER":
            _, _, rv3d = _find_any_view3d(context)
        else:
            _, region, rv3d = _find_view3d_at_mouse(
                context, event.mouse_x, event.mouse_y
            )

        # ── Numpad 5: explicit toggle out ───────────────────────────
        # We want this to work regardless of which editor the mouse is in,
        # so check it before the rv3d guard below.
        if event.type == "NUMPAD5" and event.value == "PRESS":
            _suspended_for_camera = False
            wm.ortholock_active = False
            self._cleanup(context)
            area, reg, rv3d2 = _find_any_view3d(context)
            if area and rv3d2:
                with context.temp_override(area=area, region=reg):
                    bpy.ops.view3d.view_persportho("EXEC_DEFAULT")
            return {"FINISHED"}

        if rv3d is None:
            # Mouse is not in any 3D viewport - pass everything through
            # so other editors work normally.
            return {"PASS_THROUGH"}

        # ── Camera view entered: suspend ─────────────────────────────
        if rv3d.view_perspective == "CAMERA":
            _suspended_for_camera = True
            wm.ortholock_active = False
            self._cleanup(context)
            return {"CANCELLED"}

        # ── Keep ortho locked ────────────────────────────────────────
        if rv3d.view_perspective != "ORTHO":
            rv3d.view_perspective = "ORTHO"

        # ── Free pan on plain MMB drag ───────────────────────────────
        if event.type == "MIDDLEMOUSE":
            if event.value == "PRESS":
                self._last_mouse = (event.mouse_x, event.mouse_y)
                if event.shift:
                    self._mmb_down = False
                    return {"PASS_THROUGH"}
                self._mmb_down = True
                return {"RUNNING_MODAL"}

            if event.value == "RELEASE":
                self._mmb_down = False
                self._last_mouse = (event.mouse_x, event.mouse_y)
                return {"PASS_THROUGH"}

        if (event.type == "MOUSEMOVE"
                and self._mmb_down
                and not event.shift):
            dx = event.mouse_x - self._last_mouse[0]
            dy = event.mouse_y - self._last_mouse[1]
            self._last_mouse = (event.mouse_x, event.mouse_y)
            if dx or dy:
                self._apply_pan(rv3d, region, dx, dy)
            return {"RUNNING_MODAL"}

        return {"PASS_THROUGH"}

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"WARNING"}, "OrthoLock: must be invoked from a 3D Viewport")
            return {"CANCELLED"}

        _, region, rv3d = _find_any_view3d(context)
        if rv3d is None:
            return {"CANCELLED"}

        if rv3d.view_perspective != "CAMERA":
            rv3d.view_perspective = "ORTHO"

        self._mmb_down   = False
        self._last_mouse = (event.mouse_x, event.mouse_y)

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.05, window=context.window)
        VIEW3D_OT_ortholock_modal._timers[id(context.window)] = self._timer
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    @staticmethod
    def _apply_pan(rv3d, region, dx, dy):
        if region is None or region.height == 0:
            return
        scale = rv3d.view_distance / region.height
        m     = rv3d.view_matrix
        right = Vector((m[0][0], m[0][1], m[0][2]))
        up    = Vector((m[1][0], m[1][1], m[1][2]))
        rv3d.view_location -= right * (dx * scale)
        rv3d.view_location -= up    * (dy * scale)

    def _cleanup(self, context):
        timer = VIEW3D_OT_ortholock_modal._timers.pop(id(context.window), None)
        if timer:
            try:
                context.window_manager.event_timer_remove(timer)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Update callback
# ---------------------------------------------------------------------------

def _ortholock_update(self, context):
    if context.window_manager.ortholock_active:
        _register_watcher()
        bpy.ops.view3d.ortholock_modal("INVOKE_DEFAULT")
    else:
        # Manual disable: clear suspension and stop the watcher.
        # If we were suspended for camera, _suspended_for_camera was already
        # cleared by the modal before setting this property to False, so this
        # branch is only reached on genuine manual disables.
        if not _suspended_for_camera:
            _unregister_watcher()


# ---------------------------------------------------------------------------
# Draw-callback watcher registration
# ---------------------------------------------------------------------------

def _register_watcher():
    global _watcher_handle
    if _watcher_handle is None:
        _watcher_handle = bpy.types.SpaceView3D.draw_handler_add(
            _camera_exit_watcher, (), "WINDOW", "POST_PIXEL"
        )


def _unregister_watcher():
    global _watcher_handle
    if _watcher_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_watcher_handle, "WINDOW")
        except Exception:
            pass
        _watcher_handle = None


# ---------------------------------------------------------------------------
# N-Panel
# ---------------------------------------------------------------------------

class VIEW3D_PT_ortholock(bpy.types.Panel):
    bl_label       = "OrthoLock"
    bl_idname      = "VIEW3D_PT_ortholock"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "View"
    bl_options     = {"DEFAULT_CLOSED"}
    bl_order       = 100

    def draw(self, context):
        layout = self.layout
        wm     = context.window_manager
        row    = layout.row()
        row.prop(wm, "ortholock_active", text="Orthographic Lock")
        if _suspended_for_camera:
            row.label(text="", icon="CAMERA_DATA")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

CLASSES = (
    VIEW3D_OT_ortholock_modal,
    VIEW3D_PT_ortholock,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.WindowManager.ortholock_active = BoolProperty(
        name="Orthographic Lock",
        description=(
            "Lock the viewport in Orthographic mode and pan freely without "
            "holding Shift. Suspends automatically in camera view and resumes "
            "on exit. Manually disable via Numpad 5 or this checkbox"
        ),
        default=False,
        update=_ortholock_update,
    )


def unregister():
    global _suspended_for_camera
    _suspended_for_camera = False
    _unregister_watcher()

    if bpy.context and bpy.context.window_manager:
        try:
            bpy.context.window_manager.ortholock_active = False
        except Exception:
            pass

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)

    try:
        del bpy.types.WindowManager.ortholock_active
    except Exception:
        pass


if __name__ == "__main__":
    register()
