﻿# SPDX-License-Identifier: GPL-3.0-or-later
#
# OrthoLock
# Copyright (C) 2026 Pazelock
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.



bl_info = {
    "name": "OrthoLock",
    "author": "Pazelock",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > N-Panel > View > OrthoLock",
    "description": (
        "Locks the viewport in Orthographic mode and enables free panning"
    ),
    "category": "3D View",
}

import bpy
from bpy.props import BoolProperty
from mathutils import Vector


# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

# True when OrthoLock auto-suspended itself because the user entered camera view.
# Cleared when the user manually disables the checkbox.
_suspended_for_camera = False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_view3d_area_region_rv3d(context):
    mouse_x = getattr(context, "mouse_x", -1)
    mouse_y = getattr(context, "mouse_y", -1)
    best = None
    for area in context.screen.areas:
        if area.type != "VIEW_3D":
            continue
        for region in area.regions:
            if region.type != "WINDOW":
                continue
            rv3d = area.spaces.active.region_3d
            if (area.x <= mouse_x < area.x + area.width and
                    area.y <= mouse_y < area.y + area.height):
                return area, region, rv3d
            if best is None:
                best = (area, region, rv3d)
    return best if best else (None, None, None)


def _find_any_rv3d(screen):
    """Return the first rv3d found on the given screen, or None."""
    for area in screen.areas:
        if area.type == "VIEW_3D":
            return area.spaces.active.region_3d
    return None


# ---------------------------------------------------------------------------
# Camera-exit watcher (runs as a space draw callback - lightweight)
# ---------------------------------------------------------------------------

def _camera_exit_watcher():
    """
    Called every time the 3D viewport redraws.
    If OrthoLock was suspended for camera view and the viewport is no longer
    in camera mode, re-enable the lock.
    """
    global _suspended_for_camera

    if not _suspended_for_camera:
        return

    context = bpy.context
    if context is None:
        return

    rv3d = _find_any_rv3d(context.screen)
    if rv3d is None:
        return

    if rv3d.view_perspective != "CAMERA":
        # User left camera view - re-enable the lock.
        # Prevent the update callback from thinking this is a manual enable
        # by clearing the flag first.
        _suspended_for_camera = False
        context.window_manager.ortholock_active = True


# ---------------------------------------------------------------------------
# Modal operator
# ---------------------------------------------------------------------------

class VIEW3D_OT_ortholock_modal(bpy.types.Operator):
    """Active while OrthoLock is engaged - intercepts input to enforce the lock."""
    bl_idname  = "view3d.ortholock_modal"
    bl_label   = "OrthoLock Modal"
    bl_options = {"INTERNAL"}

    _timers: dict = {}

    def modal(self, context, event):
        global _suspended_for_camera

        wm = context.window_manager

        if not wm.ortholock_active:
            self._cleanup(context)
            return {"CANCELLED"}

        area, region, rv3d = _get_view3d_area_region_rv3d(context)
        if rv3d is None:
            return {"PASS_THROUGH"}

        # Numpad 5: explicit toggle out.
        if event.type == "NUMPAD5" and event.value == "PRESS":
            _suspended_for_camera = False
            wm.ortholock_active = False
            self._cleanup(context)
            with context.temp_override(area=area, region=region):
                bpy.ops.view3d.view_persportho("EXEC_DEFAULT")
            return {"FINISHED"}

        # Camera view entered: suspend the lock and let user navigate freely.
        if rv3d.view_perspective == "CAMERA":
            _suspended_for_camera = True
            # Setting the property to False triggers _ortholock_update, but we
            # guard inside that callback so the watcher is NOT unregistered.
            wm.ortholock_active = False
            self._cleanup(context)
            return {"CANCELLED"}

        # Keep the viewport locked to orthographic.
        if rv3d.view_perspective != "ORTHO":
            rv3d.view_perspective = "ORTHO"

        # Free pan on plain MMB drag.
        if event.type == "MIDDLEMOUSE":
            if event.value == "PRESS":
                self._last_mouse = (event.mouse_x, event.mouse_y)
                if event.shift:
                    self._mmb_down = False
                    return {"PASS_THROUGH"}
                self._mmb_down = True
                return {"RUNNING_MODAL"}

            if event.value == "RELEASE":
                self._mmb_down = False
                self._last_mouse = (event.mouse_x, event.mouse_y)
                return {"PASS_THROUGH"}

        if (event.type == "MOUSEMOVE"
                and self._mmb_down
                and not event.shift):
            dx = event.mouse_x - self._last_mouse[0]
            dy = event.mouse_y - self._last_mouse[1]
            self._last_mouse = (event.mouse_x, event.mouse_y)
            if dx or dy:
                self._apply_pan(rv3d, region, dx, dy)
            return {"RUNNING_MODAL"}

        return {"PASS_THROUGH"}

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"WARNING"}, "OrthoLock: must be invoked from a 3D Viewport")
            return {"CANCELLED"}

        area, region, rv3d = _get_view3d_area_region_rv3d(context)
        if rv3d is None:
            return {"CANCELLED"}

        if rv3d.view_perspective != "CAMERA":
            rv3d.view_perspective = "ORTHO"

        self._mmb_down   = False
        self._last_mouse = (event.mouse_x, event.mouse_y)

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.05, window=context.window)
        VIEW3D_OT_ortholock_modal._timers[id(context.window)] = self._timer
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    @staticmethod
    def _apply_pan(rv3d, region, dx, dy):
        if region.height == 0:
            return
        scale = rv3d.view_distance / region.height
        m     = rv3d.view_matrix
        right = Vector((m[0][0], m[0][1], m[0][2]))
        up    = Vector((m[1][0], m[1][1], m[1][2]))
        rv3d.view_location -= right * (dx * scale)
        rv3d.view_location -= up    * (dy * scale)

    def _cleanup(self, context):
        timer = VIEW3D_OT_ortholock_modal._timers.pop(id(context.window), None)
        if timer:
            try:
                context.window_manager.event_timer_remove(timer)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Update callback
# ---------------------------------------------------------------------------

def _ortholock_update(self, context):
    global _suspended_for_camera

    if context.window_manager.ortholock_active:
        # Starting the lock: register the camera-exit watcher if needed.
        _register_watcher()
        bpy.ops.view3d.ortholock_modal("INVOKE_DEFAULT")
    else:
        # Manual disable (checkbox or Numpad 5): clear suspension flag and
        # unregister the watcher so it won't auto-resume.
        if not _suspended_for_camera:
            _unregister_watcher()
        # If _suspended_for_camera is True here, the modal itself set the
        # property to False, so we keep the watcher alive to detect camera exit.


# ---------------------------------------------------------------------------
# Draw-callback watcher registration
# ---------------------------------------------------------------------------

_watcher_handle = None


def _register_watcher():
    global _watcher_handle
    if _watcher_handle is None:
        _watcher_handle = bpy.types.SpaceView3D.draw_handler_add(
            _camera_exit_watcher, (), "WINDOW", "POST_PIXEL"
        )


def _unregister_watcher():
    global _watcher_handle
    if _watcher_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_watcher_handle, "WINDOW")
        except Exception:
            pass
        _watcher_handle = None


# ---------------------------------------------------------------------------
# N-Panel
# ---------------------------------------------------------------------------

class VIEW3D_PT_ortholock(bpy.types.Panel):
    bl_label       = "OrthoLock"
    bl_idname      = "VIEW3D_PT_ortholock"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "View"
    bl_options     = {"DEFAULT_CLOSED"}
    bl_order       = 100

    def draw(self, context):
        layout = self.layout
        wm     = context.window_manager
        row    = layout.row()
        row.prop(wm, "ortholock_active", text="Orthographic Lock")
        # Show a subtle indicator when suspended in camera view.
        if _suspended_for_camera:
            row.label(text="", icon="CAMERA_DATA")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

CLASSES = (
    VIEW3D_OT_ortholock_modal,
    VIEW3D_PT_ortholock,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.WindowManager.ortholock_active = BoolProperty(
        name="Orthographic Lock",
        description=(
            "Lock the viewport in Orthographic mode and pan freely without "
            "holding Shift. Suspends automatically in camera view and resumes "
            "on exit. Manually disable via Numpad 5 or this checkbox"
        ),
        default=False,
        update=_ortholock_update,
    )


def unregister():
    global _suspended_for_camera
    _suspended_for_camera = False
    _unregister_watcher()

    if bpy.context and bpy.context.window_manager:
        try:
            bpy.context.window_manager.ortholock_active = False
        except Exception:
            pass

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)

    try:
        del bpy.types.WindowManager.ortholock_active
    except Exception:
        pass


if __name__ == "__main__":
    register()
